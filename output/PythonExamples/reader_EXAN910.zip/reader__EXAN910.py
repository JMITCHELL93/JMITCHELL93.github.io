'''
Author: James Mitchell
Purpose: Read and plot Saved files from EXAN910 Spectrum Analyser
--Notes--
Run this script in the same directory as the files.
The script only 
'''

## Booleans ##
plot = True

## Imports ##
import os
import glob
import copy
import numpy as np
import matplotlib.pyplot as plt
plt.close('all')

## Definitions ##
def findFiles():
    global files
    path = os.path.dirname(os.path.realpath(__file__))
    files = [i for i in glob.glob('*.{}'.format('csv'))]
    
def storeFiles(fmin,fmax):
    global SA_Files
    SA_Files = {}
    for i in range(len(files)):
        array = np.loadtxt(files[i],delimiter=',',skiprows=45)
        SA_Files[files[i]] = array[(np.argmin(((array[:,0])-fmin)**2)):(np.argmin(((array[:,0])-fmax)**2)),:]
        
def measInfo(infoName):
    global SA_Info
    SA_Info = {}
    for j in range(len(files)):   
        with open(files[j]) as f:
            content = f.readlines() 
            for i in range(len(content)):
                if infoName in content[i]:
                    SA_Info[files[j]] = content[i].split(',')[1]
                    
## Code ##
# Find the files
findFiles()
# Store the files in a given frequency range
storeFiles(0e9,2e9)
# Create a log of a specified save parameter
measInfo('Y Axis Units'); units = copy.deepcopy(SA_Info); del SA_Info

## Plot ##
if plot == True:
    for i in range(len(SA_Files)):
        plt.figure('EXAN910_FilePlot',figsize=(14,7))
        forPlot = (10**((SA_Files[files[i]][:,1])/10))/1000
        forPlot = forPlot/max(forPlot)
        plt.semilogy(SA_Files[files[i]][:,0], forPlot)
        plt.xlabel('Frequency [Hz]'); plt.ylabel(units[files[i]]+' [Normalised]')
        
