'''
Author: James Mitchell
Purpose: Read and fit to CST F-domain simualtions.
--Notes--
Run this script in the same directory as the files.
Frequency is in MHz, so please alter you file or the script accordingly.
'''
#==============================================================================
# #### Python Imports and Formatting ####
#==============================================================================
## Imports
import os
import glob
import numpy as np
import matplotlib.pyplot as plt; plt.close('all')
from scipy.optimize import curve_fit
## Set-Up
dir_path = os.path.dirname(os.path.realpath(__file__))
#==============================================================================
# #### User Inputs ####
#==============================================================================
SParamName = 'V6E_Mesh_S4(1)1(1)_FullRange.txt'
window = 10 # Window size for initial mode evaluation
f_list = np.array([700, 553.5])   # Define the mode frequencies in MHz
                                # Note, one could load the eigenmode frequency array
searchScaler = int(5)
#==============================================================================
# #### Definitions ####
#==============================================================================
def fit_LR(x, amp, cen, wid):
    global yfit
    yfit = amp*np.exp(-(x-cen)**2 /wid)
    return amp*np.exp(-(x-cen)**2 /wid)
def load_SParams(extension):
    global SParams
    result = [i for i in glob.glob('*.{}'.format(extension))]
    SParams = {}
    for i in range(len(result)):
        SParams[result[i]] = np.loadtxt(result[i], delimiter='\t', skiprows=25)
def new_Range(f):
    global x, y
    space = freq[1]-freq[0]; points = round(window/space)
    location = np.argmin((freq-f)**2)
    range_l = int(round(location-points/2)); range_h = int(range_l+points)
    freq_window = freq[range_l:range_h]; mag_window = mag[range_l:range_h]
    x = freq_window*1.0; y = mag_window*1.0
def new_Range_dB(x, y, offset_dB, range_multiplier):
    global x_newRange, y_newRange
    ysearch = y[0:np.argmax(y)]; valdB = max(y)-offset_dB
    locdB = np.argmin((ysearch-valdB)**2); diff = len(ysearch)-locdB
    x_newRange = x[len(ysearch)-diff*range_multiplier:len(ysearch)+diff*range_multiplier:]
    y_newRange = y[len(ysearch)-diff*range_multiplier:len(ysearch)+diff*range_multiplier:]
    y_newRange = 10**(y_newRange/20.0)
def fit_Meas(x, y):
    global y_shift, x_init, y_init, y_best, best_vals, shift_fac
    shift_fac = min(y); y_shift = y - shift_fac
    init_vals = [max(y_shift), x[np.argmax(y_shift)], (max(x)-min(x))/10]
    x_init = np.linspace(min(x), max(x), 1000)
    fit_LR(x_init, init_vals[0], init_vals[1], init_vals[2]); y_init = yfit*1.0
    best_vals, covar = curve_fit(fit_LR, x, y_shift, p0=init_vals)
    fit_LR(x_init, best_vals[0], best_vals[1], best_vals[2]); y_best = yfit*1.0
    fit_LR(freq, init_vals[0], init_vals[1], init_vals[2]); y_entire = yfit*1.0
#==============================================================================
# #### Code ####
#==============================================================================
## Load the S-Parameters from a CST text file ##
load_SParams('txt')
## Components ##
freq = SParams[SParamName][:,0] # Note this is in MHz for me as standard, change accordingly
mag = 20*np.log10(((SParams[SParamName][:,1])**2+(SParams[SParamName][:,2])**2)**0.5)
plt.figure('S-Params', figsize=(10,7))
plt.plot(freq, mag, label = SParamName); plt.legend()
## Define Logs ##
fLog = []
QLog = []
for modeLoop in range(len(f_list)):
    ## Window ##
    new_Range(f_list[modeLoop])
    ## Range from Height ##
    new_Range_dB(x, y, 3.0, searchScaler)
    ## Fit ##
    try:
        fit_Meas(x_newRange, y_newRange)
        if len(f_list) < 3:
            figName = 'fit_lin' + str(modeLoop)
            plt.figure(figName, figsize=(10,7))
            plt.plot(x_newRange, y_shift, label = 'data')
            plt.plot(x_init, y_init, label = 'initial conditions')
            plt.plot(x_init, y_best, label = 'best fit')
            plt.xlabel('frequency [MHz]'); plt.ylabel('$S-parameter$ [linear shifted]')
            plt.legend()
        ## Back to dB ##  
        x_dB = np.linspace(min(x_init), max(x_init), num=10000)
        fit_LR(x_dB, best_vals[0], best_vals[1], best_vals[2]); y_fit_dB = 20*np.log10(yfit*1.0+shift_fac)
        if len(f_list) < 3:
            figName = 'fit_log' + str(modeLoop)
            plt.figure(figName, figsize=(10,7))
            plt.plot(x, y, label = 'data')
            plt.plot(x_dB, y_fit_dB, label = 'fit')
            plt.xlabel('frequency [MHz]'); plt.ylabel('$S-parameter$ [dB]')
            plt.legend()
        ## Ql Calculation ##
        firstHalf = y_fit_dB[0:np.argmax(y_fit_dB)]
        x_firstHalf = x_dB[0:np.argmax(y_fit_dB)]
        del_f = 2*(x_firstHalf[-1] - x_firstHalf[np.argmin((firstHalf-(max(firstHalf)-3))**2)])
        fLog.append(x_firstHalf[-1])
        Ql = x_firstHalf[-1]/del_f
        QLog.append(Ql)
    except Exception:
        pass
        print('**Fit Failure**')
        
print(fLog)
print(QLog)
#==============================================================================
print('========================================Finish=====')
#==============================================================================


    